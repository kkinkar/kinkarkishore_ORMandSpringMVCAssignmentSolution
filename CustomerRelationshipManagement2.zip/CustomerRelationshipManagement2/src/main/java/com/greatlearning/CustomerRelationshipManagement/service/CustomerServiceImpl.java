package com.greatlearning.CustomerRelationshipManagement.service;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;
import com.greatlearning.CustomerRelationshipManagement.entity.Customer;

@Repository
public class CustomerServiceImpl implements CustomerService {

	private SessionFactory sessionFactory;

	private Session session;

	public CustomerServiceImpl(SessionFactory sessionfactory) {
		this.sessionFactory = sessionfactory;
		try {
			session = this.sessionFactory.getCurrentSession();

		} catch (HibernateException e) {
			session = this.sessionFactory.openSession();
		}
	}

	@Transactional
	public Customer findById(Integer id) {
		Customer customer = session.get(Customer.class, id);
		return customer;
	}

	@Transactional
	public void save(Customer c) {
		System.out.println(c.getEmail());
		Transaction tr = session.beginTransaction();
		session.saveOrUpdate(c);
		tr.commit();
	}

	@Transactional
	public void delete(Customer c) {
		Transaction tr = session.beginTransaction();
		session.delete(c);
		tr.commit();
	}

	@Transactional
	public List<Customer> findByF_nameL_name(String f_name, String l_name) {
		List<Customer> customerList = null;
		String query = "";
		if (f_name.length() != 0 && l_name.length() != 0)
			query = "from Customer where f_name like '%" + f_name + "%' and l_name like '%" + l_name + "%'";
		else if (f_name.length() == 0 && l_name.length() != 0)
			query = "from Customer where l_name like '%" + l_name + "%'";
		else if (f_name.length() != 0 && l_name.length() == 0)
			query = "from Customer where f_name like '%" + f_name + "%'";
		else
			query = "from Customer";
		if (query.length() != 0) {
			customerList = session.createQuery(query).list();
		}
		return customerList;
	}

	@Transactional
	public List<Customer> findall() {
		List<Customer> customerList = session.createQuery("from Customer").list();
		for (Customer c : customerList) {
			System.out.println(c);
		}
		return customerList;
	}

}
