package com.greatlearning.CustomerRelationshipManagement.service;

import java.util.List;

import com.greatlearning.CustomerRelationshipManagement.entity.Customer;

public interface CustomerService {

	public Customer findById(Integer id);

	public void save(Customer c);

	public void delete(Customer c);

	public List<Customer> findall();


	public List<Customer> findByF_nameL_name(String f_name, String l_name);

}
