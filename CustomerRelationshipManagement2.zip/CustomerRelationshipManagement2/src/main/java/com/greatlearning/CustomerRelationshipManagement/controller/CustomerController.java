package com.greatlearning.CustomerRelationshipManagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.greatlearning.CustomerRelationshipManagement.entity.Customer;
import com.greatlearning.CustomerRelationshipManagement.service.CustomerService;


@Controller
@RequestMapping("/customer")

public class CustomerController {

	@Autowired
	public CustomerService customerService;//4.with this one

	@RequestMapping("/list")
	public String findAll(Model model) {
		List<Customer> customerList = customerService.findall();//4.here the customerService name should match with this one because its an object of interface
		model.addAttribute("cust", customerList);
		return "Customer";//This and the JSP file name should match, Also it should return the Customer(entity class name and this return type should be same)
	}

	@RequestMapping("/save")
	public String save(@RequestParam("id") Integer id, @RequestParam("f_name") String f_name,
			@RequestParam("l_name") String l_name, @RequestParam("email") String email) {
		System.out.println("Id:: "+id);
		System.out.println("First name:: "+f_name);
		System.out.println("Last name:: "+l_name);
		System.out.println("Email:: "+email);
		Customer c = null;// here Customer (name should be same as entity class name)
		if (id != 0) {
			c = customerService.findById(id);//here customerService(name should be same as object of interface which is 4th point
			c.setF_name(f_name);
			c.setL_name(l_name);
			c.setEmail(email);
		} else {
			c = new Customer(f_name, l_name, email);
		}
		customerService.save(c);
		return "redirect:list";
	}

	@RequestMapping("/addCustomer")
	public String addCustomer(@RequestParam("id") Integer id, Model model) {

		if (id != 0) {
			Customer c = customerService.findById(id);
			model.addAttribute("customer", c);
		} else {
			Customer c = new Customer();
			c.setId(0);
			model.addAttribute("customer", c);//1. this and
		}

		return "CustomerForm";
	}
	
	@RequestMapping("/deleteCustomer")
	public String delete(@RequestParam("id") Integer id)
	{

		Customer c=null;//@Entity @Table(name="detail")
		if(id!=-1)
		{
			c=customerService.findById(id);//@Autowired(customerService)
			customerService.delete(c);
		}
		
		return "redirect:list";
	}
	
	@RequestMapping("/search")
	public String findByF_nameL_name(@RequestParam("f_name")String f_name, @RequestParam("l_name") String l_name,Model model)
	{
		List<Customer> customerList=customerService.findByF_nameL_name(f_name,l_name) ;
		System.out.println(customerList);
		if(customerList.size()!=0)
			model.addAttribute("cust", customerList);
		else
			model.addAttribute("error", "No customer Found");
		return "Customer";
	}

}
